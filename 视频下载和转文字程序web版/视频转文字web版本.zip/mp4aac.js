// mp4aac.js —— 手写 MP4 解复用（Node 版，无 ffmpeg）
// 忠实移植 vd_asr.c 的 mp4_extract_aac 算法：解析 moov→trak→mdia→hdlr(soun)→minf→stbl，
// 读 stsz/stsc/stco 样本表，逐帧拼 ADTS+AAC 写出。
//
// 性能/内存关键点（修复 720p 卡死）：
//   .c 把整个文件 mmap/malloc 进内存，stsc/stsz/stco 全是用「内存指针」随机读，1.6 亿次也飞快。
//   本实现只把「moov 结构盒子」（通常几百 KB ~ 几 MB，远小于视频本身）读进内存做解析，
//   与 .c 的内存指针等价且快；真正的 AAC 样本字节（mdat 里的大头）仍用 fd 从磁盘随机读，
//   因此 1.2GB 视频也不会把 384MB 内存撑爆 —— 这是用户要求的「放磁盘、不放内存」方案。

'use strict';

const fs = require('fs');

// ---------- 基础读取 ----------

function rd_be32(b, off) {
  return ((b[off] << 24) | (b[off + 1] << 16) | (b[off + 2] << 8) | b[off + 3]) >>> 0;
}
function rd_be64(b, off) {
  let v = 0;
  for (let i = 0; i < 8; i++) v = v * 256 + b[off + i];
  return v;
}

// 本地 fd 读取器（绝对偏移，从磁盘随机读）—— 用于扫描顶层定位 moov，以及读取样本字节
class FdReader {
  constructor(fd) { this.fd = fd; }
  read(off, len) {
    const buf = Buffer.alloc(len);
    let pos = off, got = 0;
    while (got < len) {
      const n = fs.readSync(this.fd, buf, got, len - got, pos);
      if (n === 0) break;
      got += n; pos += n;
    }
    return buf;
  }
}

// 内存读取器：把一段连续缓冲（如 moov）以「绝对文件偏移」方式暴露。
// 解析 box / stsz / stsc / stco 全走它 = 内存随机读，与 .c 的内存指针等价且飞快。
class MemReader {
  constructor(buf, origin) { this.buf = buf; this.origin = origin; }
  read(off, len) {
    const lo = off - this.origin;
    if (lo < 0) return Buffer.alloc(len);
    return this.buf.subarray(lo, lo + len);
  }
}

// 在 [base, base+size) 区域内查找名为 type 的顶层 box（兼容 64 位 size 与 size=0 兜底）
function findBox(r, base, size, type) {
  let off = 0;
  while (off + 8 <= size) {
    const head = r.read(base + off, 8);
    if (head.length < 8) break;
    let bsize = rd_be32(head, 0);
    const btype = head.toString('latin1', 4, 8);
    let hdr = 8;
    if (bsize === 1) {
      if (off + 16 > size) break;
      bsize = rd_be64(r.read(base + off + 8, 8), 0);
      hdr = 16;
    } else if (bsize === 0) {
      bsize = size - off;
    }
    if (bsize < hdr || off + bsize > size) break;
    if (btype === type) return { off: base + off + hdr, len: bsize - hdr };
    off += bsize;
  }
  return null;
}

// 遍历 [base, base+size) 内的子 box（生成器）
function* eachChild(r, base, size) {
  let off = 0;
  while (off + 8 <= size) {
    const head = r.read(base + off, 8);
    if (head.length < 8) break;
    let bsize = rd_be32(head, 0);
    const btype = head.toString('latin1', 4, 8);
    let hdr = 8;
    if (bsize === 1) {
      if (off + 16 > size) break;
      bsize = rd_be64(r.read(base + off + 8, 8), 0);
      hdr = 16;
    } else if (bsize === 0) {
      bsize = size - off;
    }
    if (bsize < hdr || off + bsize > size) break;
    yield { type: btype, off: base + off + hdr, len: bsize - hdr };
    off += bsize;
  }
}

const AAC_SR_TABLE = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050,
  16000, 12000, 11025, 8000, 7350, 0, 0, 0];

// 解析 esds 里的 AudioSpecificConfig（DecoderSpecificInfo, tag 0x05）
function parse_esds(buf, start, len) {
  let i = 4;
  while (i + 1 < len) {
    const tag = buf[start + i];
    if (tag === 0x05) {
      let j = i + 1, dlen = 0, cnt = 0;
      while (j < len && cnt < 4) {
        const by = buf[start + j++]; dlen = (dlen << 7) | (by & 0x7f); cnt++;
        if (!(by & 0x80)) break;
      }
      if (j + 2 <= len && dlen >= 2) {
        const a0 = buf[start + j], a1 = buf[start + j + 1];
        const ot = (a0 >> 3) & 0x1f;
        const fi = ((a0 & 0x07) << 1) | ((a1 >> 7) & 0x01);
        const ch = (a1 >> 3) & 0x0f;
        return { objType: ot, freqIdx: fi, chan: ch };
      }
      return null;
    }
    i++;
  }
  return null;
}

function write_adts(profile, freqIdx, chan, frameLen) {
  const aac_frame_length = frameLen + 7;
  const out = Buffer.alloc(7);
  out[0] = 0xff;
  out[1] = 0xf1;
  out[2] = ((profile & 0x3) << 6) | ((freqIdx & 0xf) << 2) | ((chan >> 2) & 0x1);
  out[3] = ((chan & 0x3) << 6) | ((aac_frame_length >> 11) & 0x3);
  out[4] = (aac_frame_length >> 3) & 0xff;
  out[5] = ((aac_frame_length & 0x7) << 5) | 0x1f;
  out[6] = 0xfc;
  return out;
}

// ---------- 解析 MP4 结构，得到音频样本清单（与来源无关） ----------
// reader: 任意带 .read(off,len)->Buffer 的对象（本地 fd 或 moov 内存缓冲）
// moovOff/moovLen: moov 盒子「内容」在 reader 中的偏移与长度（不含 8 字节头）。
//   直接遍历 moov 的子 box（与 .c 的 mp4_iter_init(moov) 一致，无需在 moov 内再搜 moov）。
function buildAudioPlan(reader, moovOff, moovLen, fileSize) {
  // 遍历 trak，找到 handler_type == 'soun' 的音频轨（与 .c 一致）
  let audioStbl = null;
  for (const box of eachChild(reader, moovOff, moovLen)) {
    if (box.type !== 'trak') continue;
    const mdia = findBox(reader, box.off, box.len, 'mdia');
    if (!mdia) continue;
    const hdlr = findBox(reader, mdia.off, mdia.len, 'hdlr');
    if (!hdlr || hdlr.len < 12) continue;
    const handlerType = reader.read(hdlr.off + 8, 4).toString('latin1', 0, 4);
    if (handlerType !== 'soun') continue;
    const minf = findBox(reader, mdia.off, mdia.len, 'minf');
    if (!minf) continue;
    const stbl = findBox(reader, minf.off, minf.len, 'stbl');
    if (!stbl) continue;
    audioStbl = stbl;
    break;
  }
  if (!audioStbl) throw new Error('未找到音频轨(soun)，视频可能无音轨');

  // stsd -> esds（找不到就扫描原始字节）
  const stsd = findBox(reader, audioStbl.off, audioStbl.len, 'stsd');
  if (!stsd || stsd.len < 8) throw new Error('缺 stsd');
  let esds = findBox(reader, stsd.off + 8, stsd.len - 8, 'esds');
  if (!esds) {
    const region = reader.read(stsd.off, stsd.len);
    for (let k = 0; k + 4 <= stsd.len; k++) {
      if (region.toString('latin1', k, k + 4) === 'esds') {
        esds = { off: stsd.off + k + 4, len: stsd.len - (k + 4) };
        break;
      }
    }
  }
  let objType = 2, freqIdx = 4, chan = 2;
  if (esds) {
    const asc = parse_esds(reader.read(esds.off, esds.len), 0, esds.len);
    if (asc) { objType = asc.objType; freqIdx = asc.freqIdx; chan = asc.chan; }
  }
  if (freqIdx < 0 || freqIdx > 12) freqIdx = 4;
  const profile = objType - 1 < 0 ? 1 : objType - 1;
  const sampleRate = AAC_SR_TABLE[freqIdx];

  const stsz = findBox(reader, audioStbl.off, audioStbl.len, 'stsz');
  if (!stsz || stsz.len < 12) throw new Error('缺 stsz');
  const stszBuf = reader.read(stsz.off, stsz.len);
  const fixedSize = rd_be32(stszBuf, 4);
  const sampleCount = rd_be32(stszBuf, 8);
  if (sampleCount === 0) throw new Error('音频样本数为 0（无音轨或非标准封装）');
  const stszTable = stsz.off + 12;

  const stsc = findBox(reader, audioStbl.off, audioStbl.len, 'stsc');
  if (!stsc || stsc.len < 8) throw new Error('缺 stsc');
  const stscCount = rd_be32(reader.read(stsc.off, stsc.len), 4);
  const stscTable = stsc.off + 8;

  let stco = findBox(reader, audioStbl.off, audioStbl.len, 'stco');
  let is64 = false;
  if (!stco) { stco = findBox(reader, audioStbl.off, audioStbl.len, 'co64'); is64 = true; }
  if (!stco || stco.len < 8) throw new Error('缺 stco/co64');
  const chunkCount = rd_be32(reader.read(stco.off, stco.len), 4);
  const stcoTable = stco.off + 8;

  // 一次性把表读进内存（与 .c 的内存指针等价），后续逐 chunk 查表即纯内存整数运算
  const stszFull = reader.read(stszTable, sampleCount * 4);
  const stscEntries = [];
  {
    const raw = reader.read(stscTable, stscCount * 12);
    for (let e = 0; e < stscCount; e++) stscEntries.push([rd_be32(raw, e * 12), rd_be32(raw, e * 12 + 4)]);
  }
  const chunkEntries = [];
  {
    const raw = reader.read(stcoTable, chunkCount * (is64 ? 8 : 4));
    for (let c = 0; c < chunkCount; c++) {
      chunkEntries.push(is64 ? rd_be64(raw, c * 8) : rd_be32(raw, c * 4));
    }
  }

  // 逐 chunk -> 逐 sample（与 .c 的 mp4_extract_aac 主循环逐字对应）
  const samples = [];
  let sampleIdx = 0;
  for (let c = 0; c < chunkCount && sampleIdx < sampleCount; c++) {
    let spc = 1;
    for (let e = 0; e < stscCount; e++) {
      const firstChunk = stscEntries[e][0];
      const samplesPer = stscEntries[e][1];
      if (firstChunk <= c + 1) spc = samplesPer; else break;
    }
    const chunkOff = chunkEntries[c];
    let pos = chunkOff;
    for (let s = 0; s < spc && sampleIdx < sampleCount; s++) {
      const ssize = fixedSize ? fixedSize : rd_be32(stszFull, sampleIdx * 4);
      if (pos + ssize > fileSize) break;
      samples.push({ off: pos, size: ssize });
      pos += ssize;
      sampleIdx++;
    }
  }
  if (!samples.length) throw new Error('未提取到任何 AAC 样本（视频可能无音轨或非标准封装）');

  // 合并相邻（首尾相接）的样本，减少样本数组规模与后续读取次数
  const merged = [samples[0]];
  for (let i = 1; i < samples.length; i++) {
    const prev = merged[merged.length - 1];
    if (prev.off + prev.size === samples[i].off) prev.size += samples[i].size;
    else merged.push(samples[i]);
  }

  let totalBytes = 0;
  for (const s of merged) totalBytes += 7 + s.size;

  return { samples: merged, profile, freqIdx, chan, sampleRate, totalBytes, frames: samples.length };
}

// ---------- 按样本清单把音频写入 .aac（readAt 从磁盘 fd 随机读样本字节） ----------
async function writePlanToAAC(plan, readAt, aacPath) {
  const outFd = fs.openSync(aacPath, 'w');
  let written = 0;
  try {
    for (const s of plan.samples) {
      if (written + 7 + s.size > plan.totalBytes * 1.5 + 1024) {
        throw new Error('音频提取异常：输出体积远超样本清单总和，疑似 MP4 封装结构异常（手写解析无法处理）。请改用 ffmpeg 方案。');
      }
      const adts = write_adts(plan.profile, plan.freqIdx, plan.chan, s.size);
      const data = await readAt(s.off, s.size);
      fs.writeSync(outFd, adts);
      fs.writeSync(outFd, data);
      written += 7 + s.size;
    }
  } finally {
    fs.closeSync(outFd);
  }
  if (written === 0) throw new Error('音频写入为空');
  return written;
}

// ---------- 本地提取：moov 读内存解析 + 样本字节从磁盘读 ----------
async function extractAAC(mp4Path, aacPath) {
  const fd = fs.openSync(mp4Path, 'r');
  try {
    const fsize = fs.fstatSync(fd).size;
    const r = new FdReader(fd);
    // 1) 定位 moov（仅读 8 字节头、按 box 跳跃，极快）
    const moov = findBox(r, 0, fsize, 'moov');
    if (!moov) throw new Error('未找到 moov box（可能不是标准 MP4/AAC 封装）');
    // 2) 把 moov 整块读进内存（几百 KB~几 MB，安全），后续解析全在内存里（等同 .c 内存指针）
    const moovBuf = Buffer.alloc(moov.len);
    fs.readSync(fd, moovBuf, 0, moov.len, moov.off);
    const mem = new MemReader(moovBuf, moov.off);
    const plan = buildAudioPlan(mem, moov.off, moov.len, fsize);
    // 3) 样本字节从磁盘随机读（大头留在磁盘，不进内存）
    const fdRead = (off, len) => {
      const b = Buffer.alloc(len);
      let pos = off, got = 0;
      while (got < len) {
        const n = fs.readSync(fd, b, got, len - got, pos);
        if (n === 0) break;
        got += n; pos += n;
      }
      return b;
    };
    const written = await writePlanToAAC(plan, fdRead, aacPath);
    if (written > fsize * 2) {
      try { fs.unlinkSync(aacPath); } catch (_) {}
      throw new Error('音频提取异常：输出(' + (written / 1048576).toFixed(1) + 'MB)远超输入视频(' + (fsize / 1048576).toFixed(1) + 'MB)，封装结构可能非标准。建议改用 ffmpeg 方式。');
    }
    return { frames: plan.frames, sampleRate: plan.sampleRate, chan: plan.chan, totalBytes: plan.totalBytes };
  } finally {
    fs.closeSync(fd);
  }
}

// ---------- 按 ADTS 帧边界流式分片（对应 vd_asr.c 的 split_audio，AF_AAC_ADTS） ----------
async function forEachSegment(aacPath, maxChunk, cb) {
  const fd = fs.openSync(aacPath, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    const readAt = (off, len) => {
      const b = Buffer.alloc(len);
      let pos = off, got = 0;
      while (got < len) {
        const n = fs.readSync(fd, b, got, len - got, pos);
        if (n === 0) break;
        got += n; pos += n;
      }
      return b;
    };

    let pos = 0, segStart = 0, segLen = 0;
    while (pos < size) {
      if (pos + 7 > size) break;
      const h = readAt(pos, 7);
      if (!(h[0] === 0xff && (h[1] & 0xf0) === 0xf0)) {
        await cb(readAt(pos, size - pos));
        return;
      }
      let fl = ((h[3] & 0x03) << 11) | (h[4] << 3) | ((h[5] >> 5) & 0x07);
      if (fl < 7) fl = 7;
      const fend = pos + fl;
      if (fend > size) { await cb(readAt(pos, size - pos)); return; }
      if (segLen > 0 && segLen + fl > maxChunk) {
        await cb(readAt(segStart, segLen));
        segStart = pos; segLen = 0;
      }
      if (segLen === 0) segStart = pos;
      segLen += fl;
      pos = fend;
    }
    if (segLen > 0) await cb(readAt(segStart, segLen));
  } finally {
    fs.closeSync(fd);
  }
}

module.exports = { buildAudioPlan, writePlanToAAC, extractAAC, forEachSegment, FdReader, MemReader, AAC_SR_TABLE, rd_be32, rd_be64 };
